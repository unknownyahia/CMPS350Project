module.exports = {

"[project]/.next-internal/server/app/api/instructors/route/actions.js [app-rsc] (server actions loader, ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
}}),
"[externals]/next/dist/compiled/next-server/app-route.runtime.dev.js [external] (next/dist/compiled/next-server/app-route.runtime.dev.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route.runtime.dev.js"));

module.exports = mod;
}}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}}),
"[externals]/next/dist/compiled/next-server/app-page.runtime.dev.js [external] (next/dist/compiled/next-server/app-page.runtime.dev.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page.runtime.dev.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}}),
"[project]/app/response.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
const createResponse = ({ error = null, data = null, status = 200 } = {})=>{
    return new Response(JSON.stringify({
        success: error === null,
        message: error,
        data: data
    }), {
        status: status
    });
};
const __TURBOPACK__default__export__ = createResponse;
}}),
"[externals]/node:fs/promises [external] (node:fs/promises, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("node:fs/promises", () => require("node:fs/promises"));

module.exports = mod;
}}),
"[project]/app/data/users/users.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:fs/promises [external] (node:fs/promises, cjs)");
;
class Users {
    constructor(){
        this.directoryJsonData = "app/data/users/users.json";
    }
    async save(updated) {
        await __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["default"].writeFile(this.directoryJsonData, JSON.stringify(updated));
    }
    async getAll() {
        const jsonData = await __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["default"].readFile(this.directoryJsonData, "utf-8");
        const all = JSON.parse(jsonData);
        return all;
    }
    async getUserById(id) {
        const users = await this.getAll();
        return users.find((user)=>+user.id === +id);
    }
    async updateUser(user) {
        const users = await this.getAll();
        const updatedUsers = users.map((u)=>u.id === user.id ? user : u);
        await this.saveUsers(updatedUsers);
    }
    async getUserByUsernamePassword(username, password) {
        const users = await this.getAll();
        return users.find((user)=>user.username === username && user.password === password);
    }
}
const users = new Users();
const __TURBOPACK__default__export__ = users;
}}),
"[project]/app/data/instructors/instructors.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:fs/promises [external] (node:fs/promises, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$data$2f$users$2f$users$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/data/users/users.js [app-route] (ecmascript)");
;
;
class Instructors {
    constructor(){
        this.directoryJsonData = "app/data/instructors/instructors.json";
    }
    async save(updated) {
        await __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["default"].writeFile(this.directoryJsonData, JSON.stringify(updated));
    }
    async getAll() {
        const jsonData = await __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["default"].readFile(this.directoryJsonData, "utf-8");
        const all = JSON.parse(jsonData);
        return all;
    }
    async getInstructorById(id) {
        const instructors = await this.getAll();
        return instructors.find((instructor)=>+instructor.id === +id);
    }
    async getInstructorByUserId(id) {
        const instructors = await this.getAll();
        return instructors.find((instructor)=>+instructor.userId === +id);
    }
    async getInstructorData(id) {
        const instructors = await this.getAll();
        const instructor = instructors.find((instructor)=>+instructor.id === +id);
        const user = await __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$data$2f$users$2f$users$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"].getUserById(instructor.userId);
        return {
            ...instructor,
            name: user.name
        };
    }
    async getInstructorsData() {
        const instructors = await this.getAll();
        for (const instructor of instructors){
            const user = await __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$data$2f$users$2f$users$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"].getUserById(instructor.userId);
            instructor.name = user.name;
        }
        return instructors;
    }
    async updateInstructor(instructor) {
        const instructors = await this.getAll();
        const updatedInstructors = instructors.map((i)=>i.id === instructor.id ? instructor : i);
        await this.save(updatedInstructors);
    }
}
const instructors = new Instructors();
const __TURBOPACK__default__export__ = instructors;
}}),
"[project]/app/api/instructors/route.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "GET": (()=>GET)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$response$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/response.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$data$2f$instructors$2f$instructors$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/data/instructors/instructors.js [app-route] (ecmascript)");
;
;
async function GET(request) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$response$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"])({
        data: await __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$data$2f$instructors$2f$instructors$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"].getInstructorsData()
    });
}
}}),

};

//# sourceMappingURL=%5Broot%20of%20the%20server%5D__1bdc5cdd._.js.map