module.exports = {

"[project]/.next-internal/server/app/login/route/actions.js [app-rsc] (server actions loader, ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
}}),
"[externals]/next/dist/compiled/next-server/app-route.runtime.dev.js [external] (next/dist/compiled/next-server/app-route.runtime.dev.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route.runtime.dev.js"));

module.exports = mod;
}}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}}),
"[externals]/next/dist/compiled/next-server/app-page.runtime.dev.js [external] (next/dist/compiled/next-server/app-page.runtime.dev.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page.runtime.dev.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}}),
"[externals]/node:fs/promises [external] (node:fs/promises, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("node:fs/promises", () => require("node:fs/promises"));

module.exports = mod;
}}),
"[project]/app/data/users/users.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:fs/promises [external] (node:fs/promises, cjs)");
;
class Users {
    constructor(){
        this.directoryJsonData = "app/data/users/users.json";
    }
    async save(updated) {
        await __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["default"].writeFile(this.directoryJsonData, JSON.stringify(updated));
    }
    async getAll() {
        const jsonData = await __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["default"].readFile(this.directoryJsonData, "utf-8");
        const all = JSON.parse(jsonData);
        return all;
    }
    async getUserById(id) {
        const users = await this.getAll();
        return users.find((user)=>+user.id === +id);
    }
    async updateUser(user) {
        const users = await this.getAll();
        const updatedUsers = users.map((u)=>u.id === user.id ? user : u);
        await this.saveUsers(updatedUsers);
    }
    async getUserByUsernamePassword(username, password) {
        const users = await this.getAll();
        return users.find((user)=>user.username === username && user.password === password);
    }
}
const users = new Users();
const __TURBOPACK__default__export__ = users;
}}),
"[project]/app/response.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
const createResponse = ({ error = null, data = null, status = 200 } = {})=>{
    return new Response(JSON.stringify({
        success: error === null,
        message: error,
        data: data
    }), {
        status: status
    });
};
const __TURBOPACK__default__export__ = createResponse;
}}),
"[project]/app/login/route.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "POST": (()=>POST)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$data$2f$users$2f$users$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/data/users/users.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$response$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/response.js [app-route] (ecmascript)");
;
;
async function POST(request) {
    const data = await request.json();
    const user = await __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$data$2f$users$2f$users$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"].getUserByUsernamePassword(data.username, data.password);
    if (user) return (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$response$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"])({
        data: user
    });
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$response$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"])({
        error: "Invalid username or password",
        status: 401
    });
}
}}),

};

//# sourceMappingURL=%5Broot%20of%20the%20server%5D__1979af1e._.js.map