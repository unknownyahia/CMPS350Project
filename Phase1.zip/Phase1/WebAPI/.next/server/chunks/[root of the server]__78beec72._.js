module.exports = {

"[project]/.next-internal/server/app/acceptPending/route/actions.js [app-rsc] (server actions loader, ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
}}),
"[externals]/next/dist/compiled/next-server/app-route.runtime.dev.js [external] (next/dist/compiled/next-server/app-route.runtime.dev.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route.runtime.dev.js"));

module.exports = mod;
}}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}}),
"[externals]/next/dist/compiled/next-server/app-page.runtime.dev.js [external] (next/dist/compiled/next-server/app-page.runtime.dev.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page.runtime.dev.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}}),
"[externals]/node:fs/promises [external] (node:fs/promises, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("node:fs/promises", () => require("node:fs/promises"));

module.exports = mod;
}}),
"[project]/app/data/users/users.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:fs/promises [external] (node:fs/promises, cjs)");
;
class Users {
    constructor(){
        this.directoryJsonData = "app/data/users/users.json";
    }
    async save(updated) {
        await __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["default"].writeFile(this.directoryJsonData, JSON.stringify(updated));
    }
    async getAll() {
        const jsonData = await __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["default"].readFile(this.directoryJsonData, "utf-8");
        const all = JSON.parse(jsonData);
        return all;
    }
    async getUserById(id) {
        const users = await this.getAll();
        return users.find((user)=>+user.id === +id);
    }
    async updateUser(user) {
        const users = await this.getAll();
        const updatedUsers = users.map((u)=>u.id === user.id ? user : u);
        await this.saveUsers(updatedUsers);
    }
    async getUserByUsernamePassword(username, password) {
        const users = await this.getAll();
        return users.find((user)=>user.username === username && user.password === password);
    }
}
const users = new Users();
const __TURBOPACK__default__export__ = users;
}}),
"[project]/app/response.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
const createResponse = ({ error = null, data = null, status = 200 } = {})=>{
    return new Response(JSON.stringify({
        success: error === null,
        message: error,
        data: data
    }), {
        status: status
    });
};
const __TURBOPACK__default__export__ = createResponse;
}}),
"[project]/app/data/students/students.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:fs/promises [external] (node:fs/promises, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$data$2f$users$2f$users$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/data/users/users.js [app-route] (ecmascript)");
;
;
class Students {
    constructor(){
        this.directoryJsonData = "app/data/students/students.json";
    }
    async save(updated) {
        await __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["default"].writeFile(this.directoryJsonData, JSON.stringify(updated));
    }
    async getAll() {
        const jsonData = await __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["default"].readFile(this.directoryJsonData, "utf-8");
        const all = JSON.parse(jsonData);
        return all;
    }
    async getStudentById(id) {
        const students = await this.getAll();
        return students.find((student)=>+student.id === +id);
    }
    async getStudentByUserId(userId) {
        const students = await this.getAll();
        return students.find((student)=>+student.userId === +userId);
    }
    async getstudentData(id) {
        const student = await this.getStudentById(id);
        const user = await __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$data$2f$users$2f$users$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"].getUserById(student.userId);
        return {
            ...student,
            name: user.name
        };
    }
    async updateStudent(student) {
        const students = await this.getAll();
        const updatedStudents = students.map((s)=>s.id === student.id ? student : s);
        await this.save(updatedStudents);
    }
}
const students = new Students();
const __TURBOPACK__default__export__ = students;
}}),
"[project]/app/data/courses/courses.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:fs/promises [external] (node:fs/promises, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$data$2f$users$2f$users$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/data/users/users.js [app-route] (ecmascript)");
;
;
class Courses {
    constructor(){
        this.directoryJsonData = "app/data/courses/courses.json";
    }
    async save(updated) {
        await __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["default"].writeFile(this.directoryJsonData, JSON.stringify(updated));
    }
    async getAll() {
        const jsonData = await __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["default"].readFile(this.directoryJsonData, "utf-8");
        const all = JSON.parse(jsonData);
        return all;
    }
    async getCourseById(id) {
        const courses = await this.getAll();
        return courses.find((course)=>course.id === id);
    }
    async getCourseByName(name) {
        const courses = await this.getAll();
        return courses.filter((course)=>course.name.includes(name));
    }
    async updateCourse(updated) {
        const courses = await this.getAll();
        const updatedCourses = courses.map((i)=>i.id === updated.id ? updated : i);
        await this.save(updatedCourses);
    }
}
const courses = new Courses();
const __TURBOPACK__default__export__ = courses;
}}),
"[project]/app/data/classes/classes.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:fs/promises [external] (node:fs/promises, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$data$2f$courses$2f$courses$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/data/courses/courses.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$data$2f$studentCourses$2f$studentsClasses$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/data/studentCourses/studentsClasses.js [app-route] (ecmascript)");
;
;
;
class Classes {
    constructor(){
        this.directoryJsonData = "app/data/classes/classes.json";
    }
    async save(updated) {
        await __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["default"].writeFile(this.directoryJsonData, JSON.stringify(updated));
    }
    async getAll() {
        const jsonData = await __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["default"].readFile(this.directoryJsonData, "utf-8");
        const all = JSON.parse(jsonData);
        for (const Class of all){
            Class.name = (await __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$data$2f$courses$2f$courses$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"].getCourseById(Class.courseId)).name;
            Class.numberPending = (await __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$data$2f$studentCourses$2f$studentsClasses$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"].getStudentClassesByClassId(Class.id, "pending")).length;
            Class.numberRegistered = (await __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$data$2f$studentCourses$2f$studentsClasses$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"].getStudentClassesByClassId(Class.id, "registered")).length;
            Class.numberFinalized = (await __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$data$2f$studentCourses$2f$studentsClasses$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"].getStudentClassesByClassId(Class.id, "finalized")).length;
            Class.numbeAllStudents = Class.numberPending + Class.numberRegistered + Class.numberFinalized;
        }
        return all;
    }
    async getClassById(id) {
        const Classes = await this.getAll();
        return Classes.find((Class)=>+Class.id === +id);
    }
    async getAllClassesByName(name) {
        const classes = await this.getAll();
        return classes.filter((Class)=>Class.name.toLowerCase().includes(name.toLowerCase()));
    }
    async getClassesByInstructorId(instructorId) {
        const classes = await this.getAll();
        return classes.filter((Class)=>+Class.instructorId === +instructorId);
    }
    async getClassesByInstructorIdAndName(instructorId, name) {
        const classes = await this.getClassesByInstructorId(instructorId);
        return classes.filter((Class)=>Class.name.toLowerCase().includes(name.toLowerCase()));
    }
    async updateClass(updated) {
        const classes = await this.getAll();
        const updatedClasses = classes.map((i)=>i.id === updated.id ? updated : i);
        await this.save(updatedClasses);
    }
}
const classes = new Classes();
const __TURBOPACK__default__export__ = classes;
}}),
"[project]/app/data/studentCourses/studentsClasses.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:fs/promises [external] (node:fs/promises, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$data$2f$classes$2f$classes$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/data/classes/classes.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$data$2f$students$2f$students$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/data/students/students.js [app-route] (ecmascript)");
;
;
;
class StudentsClasses {
    constructor(){
        this.directoryJsonData = "app/data/studentCourses/studentsClasses.json";
    }
    async save(updated) {
        await __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["default"].writeFile(this.directoryJsonData, JSON.stringify(updated));
    }
    async getAll() {
        const jsonData = await __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["default"].readFile(this.directoryJsonData, "utf-8");
        const all = JSON.parse(jsonData);
        return all;
    }
    async createStudentClass(studentClass) {
        const studentClasses = await this.getAll();
        const nextId = studentClasses.reduce((max, studentClass)=>Math.max(max, studentClass.id), 0) + 1;
        studentClasses.push({
            ...studentClass,
            id: nextId
        });
        await this.save(studentClasses);
    }
    async getStudentClassById(id) {
        const studentsClasses = await this.getAll();
        return studentsClasses.find((studentClass)=>+studentClass.id === +id);
    }
    async getStudentClassesByClassId(classId, status = "All") {
        const studentClasses = (await this.getAll()).filter((studentClass)=>+studentClass.classId === +classId && (studentClass.status === status || status === "All"));
        for (const studentClass of studentClasses){
            studentClass.student_name = (await __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$data$2f$students$2f$students$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"].getstudentData(studentClass.studentId)).name;
        }
        return studentClasses;
    }
    async getStudentClassesByStudentId(studentId) {
        const studentClasses = await this.getAll();
        return studentClasses.filter((studentClass)=>+studentClass.studentId === +studentId);
    }
    async getAllClassesByStudentId(studentId) {
        const classesData = await __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$data$2f$classes$2f$classes$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"].getAll();
        const studentClasses = await this.getStudentClassesByStudentId(studentId);
        return classesData.map((Class)=>({
                ...Class,
                studentClasse: studentClasses.find((studentClass)=>+studentClass.classId === +Class.id)
            }));
    }
    async getAllClassesByStudentIdAndName(studentId, name) {
        const allClassesByStudentId = await this.getAllClassesByStudentId(studentId);
        return allClassesByStudentId.filter((Class)=>Class.name.toLowerCase().includes(name.toLowerCase()));
    }
    async updatedStudentClass(updated) {
        const studentClasses = await this.getAll();
        const updatedStudentClasses = studentClasses.map((i)=>+i.id === +updated.id ? updated : i);
        await this.save(updatedStudentClasses);
    }
    async deleteStudentClass(id) {
        const studentClasses = await this.getAll();
        const updatedStudentClasses = studentClasses.filter((studentClass)=>+studentClass.id !== +id);
        await this.save(updatedStudentClasses);
    }
}
const studentsClasses = new StudentsClasses();
const __TURBOPACK__default__export__ = studentsClasses;
}}),
"[project]/app/data/instructors/instructors.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:fs/promises [external] (node:fs/promises, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$data$2f$users$2f$users$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/data/users/users.js [app-route] (ecmascript)");
;
;
class Instructors {
    constructor(){
        this.directoryJsonData = "app/data/instructors/instructors.json";
    }
    async save(updated) {
        await __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["default"].writeFile(this.directoryJsonData, JSON.stringify(updated));
    }
    async getAll() {
        const jsonData = await __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["default"].readFile(this.directoryJsonData, "utf-8");
        const all = JSON.parse(jsonData);
        return all;
    }
    async getInstructorById(id) {
        const instructors = await this.getAll();
        return instructors.find((instructor)=>+instructor.id === +id);
    }
    async getInstructorByUserId(id) {
        const instructors = await this.getAll();
        return instructors.find((instructor)=>+instructor.userId === +id);
    }
    async getInstructorData(id) {
        const instructors = await this.getAll();
        const instructor = instructors.find((instructor)=>+instructor.id === +id);
        const user = await __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$data$2f$users$2f$users$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"].getUserById(instructor.userId);
        return {
            ...instructor,
            name: user.name
        };
    }
    async updateInstructor(instructor) {
        const instructors = await this.getAll();
        const updatedInstructors = instructors.map((i)=>i.id === instructor.id ? instructor : i);
        await this.save(updatedInstructors);
    }
}
const instructors = new Instructors();
const __TURBOPACK__default__export__ = instructors;
}}),
"[project]/app/data/administrators/administrators.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:fs/promises [external] (node:fs/promises, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$data$2f$users$2f$users$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/data/users/users.js [app-route] (ecmascript)");
;
;
class Administrators {
    constructor(){
        this.directoryJsonData = "app/data/administrators/administrators.json";
    }
    async save(updated) {
        await __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["default"].writeFile(this.directoryJsonData, JSON.stringify(updated));
    }
    async getAll() {
        const jsonData = await __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["default"].readFile(this.directoryJsonData, "utf-8");
        const all = JSON.parse(jsonData);
        return all;
    }
    async getAdministratorById(id) {
        const administrators = await this.getAll();
        return administrators.find((administrator)=>+administrator.id === +id);
    }
    async getAdministratorByUserId(id) {
        const administrators = await this.getAll();
        return administrators.find((administrator)=>+administrator.userId === +id);
    }
    async getAdministratorData(id) {
        const administrators = await this.getAll();
        const administrator = administrators.find((admin)=>+admin.id === +id);
        const user = await __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$data$2f$users$2f$users$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"].getUserById(administrator.userId);
        return {
            ...administrator,
            name: user.name
        };
    }
    async updateAdministrator(administrator) {
        const administrators = await this.getAll();
        const updatedAdministrators = administrators.map((a)=>a.id === administrator.id ? administrator : a);
        await this.save(updatedAdministrators);
    }
}
const administrators = new Administrators();
const __TURBOPACK__default__export__ = administrators;
}}),
"[project]/app/acceptPending/route.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "DELETE": (()=>DELETE),
    "GET": (()=>GET),
    "PATCH": (()=>PATCH)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$data$2f$users$2f$users$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/data/users/users.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$response$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/response.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$data$2f$students$2f$students$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/data/students/students.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$data$2f$studentCourses$2f$studentsClasses$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/data/studentCourses/studentsClasses.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$data$2f$instructors$2f$instructors$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/data/instructors/instructors.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$data$2f$classes$2f$classes$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/data/classes/classes.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$data$2f$administrators$2f$administrators$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/data/administrators/administrators.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$data$2f$courses$2f$courses$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/data/courses/courses.js [app-route] (ecmascript)");
;
;
;
;
;
;
;
;
async function GET(request) {
    const { searchParams } = request.nextUrl;
    const classId = searchParams.get("classId");
    const Class = await __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$data$2f$classes$2f$classes$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"].getClassById(classId);
    const studentsClassesData = await __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$data$2f$studentCourses$2f$studentsClasses$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"].getStudentClassesByClassId(classId, "pending");
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$response$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"])({
        data: {
            ...Class,
            studentsClassesData
        }
    });
}
async function PATCH(request) {
    const data = await request.json();
    const StudentClass = await __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$data$2f$studentCourses$2f$studentsClasses$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"].getStudentClassById(data.studentClassId);
    StudentClass.status = "registered";
    await __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$data$2f$studentCourses$2f$studentsClasses$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"].updatedStudentClass(StudentClass);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$response$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"])({
        data: "done"
    });
}
async function DELETE(request) {
    const data = await request.json();
    await __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$data$2f$studentCourses$2f$studentsClasses$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"].deleteStudentClass(data.studentClassId);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$response$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"])({
        data: "done"
    });
}
}}),

};

//# sourceMappingURL=%5Broot%20of%20the%20server%5D__78beec72._.js.map